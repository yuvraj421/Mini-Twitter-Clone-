// User login
export const SET_USER = "SET_USER";
// Update any changes
export const SET_UPDATE = "SET_UPDATE";
// Theme
export const SET_THEME = "SET_THEME";
// Logout user
export const LOGOUT_USER = "LOGOUT_USER";
